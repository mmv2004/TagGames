package com.example.taggames;

public class Record {
    private int id;
    private String playerName;
    private int timeInSeconds;
    private int moveCount;
    private int boardSize;
    private String date;

    public Record() {
    }

    public Record(String playerName, int timeInSeconds, int moveCount, int boardSize, String date) {
        this.playerName = playerName;
        this.timeInSeconds = timeInSeconds;
        this.moveCount = moveCount;
        this.boardSize = boardSize;
        this.date = date;
    }

    public Record(int id, String playerName, int timeInSeconds, int moveCount, int boardSize, String date) {
        this.id = id;
        this.playerName = playerName;
        this.timeInSeconds = timeInSeconds;
        this.moveCount = moveCount;
        this.boardSize = boardSize;
        this.date = date;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPlayerName() {
        return playerName;
    }

    public void setPlayerName(String playerName) {
        this.playerName = playerName;
    }

    public int getTimeInSeconds() {
        return timeInSeconds;
    }

    public void setTimeInSeconds(int timeInSeconds) {
        this.timeInSeconds = timeInSeconds;
    }

    public int getMoveCount() {
        return moveCount;
    }

    public void setMoveCount(int moveCount) {
        this.moveCount = moveCount;
    }

    public int getBoardSize() {
        return boardSize;
    }

    public void setBoardSize(int boardSize) {
        this.boardSize = boardSize;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    @Override
    public String toString() {
        return "Record{" +
                "id=" + id +
                ", playerName='" + playerName + '\'' +
                ", timeInSeconds=" + timeInSeconds +
                ", moveCount=" + moveCount +
                ", boardSize=" + boardSize +
                ", date='" + date + '\'' +
                '}';
    }
}

package com.example.taggames;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private Button btn3x3, btn4x4, btn5x5, btnRecords;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn3x3 = findViewById(R.id.btn3x3);
        btn4x4 = findViewById(R.id.btn4x4);
        btn5x5 = findViewById(R.id.btn5x5);
        btnRecords = findViewById(R.id.btnRecords);

        btn3x3.setOnClickListener(v -> startGame(3));
        btn4x4.setOnClickListener(v -> startGame(4));
        btn5x5.setOnClickListener(v -> startGame(5));
        btnRecords.setOnClickListener(v -> startActivity(new Intent(this, RecordsActivity.class)));
    }

    private void startGame(int size) {
        Intent intent = new Intent(this, GameActivity.class);
        intent.putExtra("gridSize", size);
        startActivity(intent);
    }
}

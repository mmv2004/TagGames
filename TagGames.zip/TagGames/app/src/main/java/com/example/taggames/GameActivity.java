package com.example.taggames;

import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.View;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.Locale;

public class GameActivity extends AppCompatActivity {

    private GridLayout gridLayout;
    private TextView tvTimer, tvMoves;
    private Button btnBack;
    private TextView btnRestart;

    private int gridSize = 3;
    private int emptyX, emptyY;
    private int moves = 0;
    private long startTime;
    private Handler timerHandler = new Handler();
    private boolean isGameRunning = false;
    private DatabaseHelper db;

    // 🔥 ВАЖНО: теперь TextView
    private TextView[][] tiles;
    private int[][] tileValues;

    private final Runnable timerRunnable = new Runnable() {
        @Override
        public void run() {
            if (isGameRunning) {
                long elapsed = (System.currentTimeMillis() - startTime) / 1000;
                tvTimer.setText("Время: " + elapsed + " сек");
                timerHandler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game);

        gridSize = getIntent().getIntExtra("gridSize", 3);

        gridLayout = findViewById(R.id.gridLayout);
        tvTimer = findViewById(R.id.tvTimer);
        tvMoves = findViewById(R.id.tvMoves);
        btnRestart = findViewById(R.id.btnRestart);
        btnBack = findViewById(R.id.btnBack);
        db = new DatabaseHelper(this);

        btnRestart.setOnClickListener(v -> startNewGame());
        btnBack.setOnClickListener(v -> finish());

        startNewGame();
    }

    private void startNewGame() {
        gridLayout.removeAllViews();
        gridLayout.setColumnCount(gridSize);
        gridLayout.setRowCount(gridSize);

        tiles = new TextView[gridSize][gridSize];
        tileValues = new int[gridSize][gridSize];

        ArrayList<Integer> numbers = new ArrayList<>();
        for (int i = 1; i < gridSize * gridSize; i++) numbers.add(i);
        numbers.add(0);

        do {
            Collections.shuffle(numbers);
        } while (!isSolvable(numbers));

        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                int number = numbers.get(i * gridSize + j);
                tileValues[i][j] = number;

                if (number == 0) {
                    emptyX = i;
                    emptyY = j;
                    continue;
                }

                // 🔥 TextView вместо Button
                TextView tile = new TextView(this);
                tile.setText(String.valueOf(number));
                tile.setTextColor(Color.WHITE);
                tile.setTextSize(24);
                tile.setGravity(Gravity.CENTER);

                tile.setClickable(true);
                tile.setFocusable(true);

                tile.setBackgroundResource(R.drawable.tile_background);

                GridLayout.LayoutParams params = new GridLayout.LayoutParams();
                params.width = getTileSize();
                params.height = getTileSize();
                params.rowSpec = GridLayout.spec(i);
                params.columnSpec = GridLayout.spec(j);
                params.setMargins(2, 2, 2, 2);
                tile.setLayoutParams(params);

                tile.setTag(new int[]{i, j});
                tile.setOnClickListener(v -> {
                    int[] pos = (int[]) v.getTag();
                    handleTileClick(pos[0], pos[1]);
                });

                tiles[i][j] = tile;
                gridLayout.addView(tile);
            }
        }

        moves = 0;
        tvMoves.setText("Ходы: 0");
        startTime = System.currentTimeMillis();
        isGameRunning = true;
        timerHandler.post(timerRunnable);
    }

    private int getTileSize() {
        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int min = Math.min(dm.widthPixels, dm.heightPixels);
        int padding = (int) (32 * dm.density);
        int margins = (int) (8 * dm.density * (gridSize - 1));

        return (min - padding - margins) / gridSize;
    }

    private void handleTileClick(int x, int y) {
        if (isAdjacentToEmpty(x, y)) moveTile(x, y);
    }

    private boolean isAdjacentToEmpty(int x, int y) {
        return (Math.abs(emptyX - x) == 1 && emptyY == y) ||
                (Math.abs(emptyY - y) == 1 && emptyX == x);
    }

    private void moveTile(int x, int y) {
        TextView tile = tiles[x][y];
        int value = tileValues[x][y];

        tileValues[emptyX][emptyY] = value;
        tileValues[x][y] = 0;

        GridLayout.LayoutParams params = (GridLayout.LayoutParams) tile.getLayoutParams();
        params.rowSpec = GridLayout.spec(emptyX);
        params.columnSpec = GridLayout.spec(emptyY);
        tile.setLayoutParams(params);

        tile.setTag(new int[]{emptyX, emptyY});
        tiles[emptyX][emptyY] = tile;
        tiles[x][y] = null;

        emptyX = x;
        emptyY = y;

        moves++;
        tvMoves.setText("Ходы: " + moves);

        if (isSolved()) {
            isGameRunning = false;
            timerHandler.removeCallbacks(timerRunnable);
            long time = (System.currentTimeMillis() - startTime) / 1000;
            showWinDialog(time);
        }
    }

    private boolean isSolved() {
        int expected = 1;
        for (int i = 0; i < gridSize; i++) {
            for (int j = 0; j < gridSize; j++) {
                if (i == gridSize - 1 && j == gridSize - 1) {
                    if (tileValues[i][j] != 0) return false;
                } else if (tileValues[i][j] != expected++) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean isSolvable(ArrayList<Integer> nums) {
        int inv = 0;
        for (int i = 0; i < nums.size(); i++)
            for (int j = i + 1; j < nums.size(); j++)
                if (nums.get(i) != 0 && nums.get(j) != 0 && nums.get(i) > nums.get(j))
                    inv++;

        if (gridSize % 2 == 1) return inv % 2 == 0;

        int emptyRow = gridSize - (nums.indexOf(0) / gridSize);
        return (emptyRow % 2 == 0) == (inv % 2 == 1);
    }

    private void showWinDialog(long time) {
        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle("Победа!");
        b.setMessage("Вы прошли игру за " + time + " сек и " + moves + " ходов.\nВведите имя:");

        View v = getLayoutInflater().inflate(R.layout.dialog_name_input, null);
        b.setView(v);

        b.setPositiveButton("OK", (d, w) -> {
            TextView et = v.findViewById(R.id.etName);
            String name = et.getText().toString().trim();
            if (name.isEmpty()) name = "Игрок";

            String date = new SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(new Date());
            db.addRecord(new Record(name, (int) time, moves, gridSize, date));
            finish();
        });

        b.setCancelable(false);
        b.show();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        timerHandler.removeCallbacks(timerRunnable);
    }
}

package com.example.taggames;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "records.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_RECORDS = "records";

    private static final String COLUMN_ID = "_id";
    private static final String COLUMN_PLAYER_NAME = "player_name";
    private static final String COLUMN_TIME_SECONDS = "time_seconds";
    private static final String COLUMN_MOVE_COUNT = "move_count";
    private static final String COLUMN_BOARD_SIZE = "board_size";
    private static final String COLUMN_DATE_ADDED = "date_added";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(
                "CREATE TABLE " + TABLE_RECORDS + " (" +
                        COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        COLUMN_PLAYER_NAME + " TEXT, " +
                        COLUMN_TIME_SECONDS + " INTEGER, " +
                        COLUMN_MOVE_COUNT + " INTEGER, " +
                        COLUMN_BOARD_SIZE + " INTEGER, " +
                        COLUMN_DATE_ADDED + " TEXT" +
                        ")"
        );
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_RECORDS);
        onCreate(db);
    }

    public void addRecord(Record record) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_PLAYER_NAME, record.getPlayerName());
        values.put(COLUMN_TIME_SECONDS, record.getTimeInSeconds());
        values.put(COLUMN_MOVE_COUNT, record.getMoveCount());
        values.put(COLUMN_BOARD_SIZE, record.getBoardSize());
        values.put(COLUMN_DATE_ADDED, record.getDate());
        db.insert(TABLE_RECORDS, null, values);
        db.close();
    }

    public List<Record> getRecordsByTime(int boardSize) {
        return getRecords(boardSize, COLUMN_TIME_SECONDS);
    }

    public List<Record> getRecordsByMoves(int boardSize) {
        return getRecords(boardSize, COLUMN_MOVE_COUNT);
    }

    private List<Record> getRecords(int boardSize, String orderBy) {
        List<Record> list = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();

        Cursor cursor = db.query(
                TABLE_RECORDS,
                null,
                COLUMN_BOARD_SIZE + "=?",
                new String[]{String.valueOf(boardSize)},
                null,
                null,
                orderBy + " ASC"
        );

        while (cursor.moveToNext()) {
            Record r = new Record(
                    cursor.getInt(0),
                    cursor.getString(1),
                    cursor.getInt(2),
                    cursor.getInt(3),
                    cursor.getInt(4),
                    cursor.getString(5)
            );
            list.add(r);
        }

        cursor.close();
        db.close();
        return list;
    }

    // УДАЛЕНИЕ ОДНОЙ ЗАПИСИ
    public void deleteRecord(int id) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(TABLE_RECORDS, COLUMN_ID + "=?", new String[]{String.valueOf(id)});
        db.close();
    }
}

package com.example.taggames;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class RecordsActivity extends AppCompatActivity {

    private ListView listView;
    private Button btnBack, btnSortTime, btnSortMoves;
    private Button btnSize3, btnSize4, btnSize5;

    private DatabaseHelper db;
    private int currentBoardSize = 3;
    private boolean sortByTime = true;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);

        listView = findViewById(R.id.listView);
        btnBack = findViewById(R.id.btnBack);
        btnSortTime = findViewById(R.id.btnSortTime);
        btnSortMoves = findViewById(R.id.btnSortMoves);
        btnSize3 = findViewById(R.id.btnSize3);
        btnSize4 = findViewById(R.id.btnSize4);
        btnSize5 = findViewById(R.id.btnSize5);

        db = new DatabaseHelper(this);

        btnBack.setOnClickListener(v -> finish());

        btnSortTime.setOnClickListener(v -> {
            sortByTime = true;
            loadRecords();
        });

        btnSortMoves.setOnClickListener(v -> {
            sortByTime = false;
            loadRecords();
        });

        btnSize3.setOnClickListener(v -> setSize(3));
        btnSize4.setOnClickListener(v -> setSize(4));
        btnSize5.setOnClickListener(v -> setSize(5));

        loadRecords();
    }

    private void setSize(int size) {
        currentBoardSize = size;
        loadRecords();
    }

    private void loadRecords() {
        List<Record> records = sortByTime
                ? db.getRecordsByTime(currentBoardSize)
                : db.getRecordsByMoves(currentBoardSize);

        showRecords(records);
    }

    private void showRecords(List<Record> records) {

        if (records.isEmpty()) {
            List<String> empty = new ArrayList<>();
            empty.add("📝 Пока нет рекордов");

            listView.setAdapter(new ArrayAdapter<>(
                    this, android.R.layout.simple_list_item_1, empty));
            return;
        }

        ArrayAdapter<Record> adapter = new ArrayAdapter<Record>(
                this, android.R.layout.simple_list_item_1, records) {

            @Override
            public View getView(int position, View convertView, ViewGroup parent) {
                TextView tv = (TextView) super.getView(position, convertView, parent);

                Record r = getItem(position);

                // Медали для первых трёх мест
                String medal;
                if (position == 0) medal = "🥇";
                else if (position == 1) medal = "🥈";
                else if (position == 2) medal = "🥉";
                else medal = "";

                // Текст рекорда
                tv.setText(medal + " " + r.getPlayerName() +
                        "\n⏱ " + r.getTimeInSeconds() + " сек | 🎯 " + r.getMoveCount() + " ходов\n📅 " + r.getDate());

                tv.setTextColor(Color.WHITE);
                tv.setPadding(16, 16, 16, 16);
                tv.setTextSize(16f);

                // Фон: золотой для первого, обычный для остальных
                if (position == 0) {
                    tv.setBackgroundColor(Color.parseColor("#FFD700")); // золотой
                } else if (position == 1) {
                    tv.setBackgroundColor(Color.parseColor("#C0C0C0")); // серебро
                } else if (position == 2) {
                    tv.setBackgroundColor(Color.parseColor("#CD7F32")); // бронза
                } else {
                    tv.setBackgroundResource(R.drawable.record_item_bg); // обычный фон
                }

                return tv;
            }
        };


        listView.setAdapter(adapter);

        // 🔥 УДАЛЕНИЕ ПО ДОЛГОМУ НАЖАТИЮ
        listView.setOnItemLongClickListener((p, v, pos, id) -> {
            Record r = records.get(pos);

            new AlertDialog.Builder(this)
                    .setTitle("Удалить рекорд?")
                    .setMessage(r.getPlayerName())
                    .setPositiveButton("Удалить", (d, w) -> {
                        db.deleteRecord(r.getId());
                        loadRecords();
                    })
                    .setNegativeButton("Отмена", null)
                    .show();

            return true;
        });
    }
}
